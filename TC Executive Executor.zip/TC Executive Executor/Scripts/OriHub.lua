--Ori Hub v1.9
loadstring(game:HttpGet('https://virtuallization.com/OriHubMain.txt'))()
