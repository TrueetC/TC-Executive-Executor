-- Gui to Lua
-- Version: 3.2

-- Instances:

local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local combatgui1 = Instance.new("TextButton")
local combatgui2 = Instance.new("TextButton")
local combatgui3 = Instance.new("TextButton")
local autofarmgui1 = Instance.new("TextButton")
local autofarmgui2 = Instance.new("TextButton")
local TextButton = Instance.new("TextButton")
local TextLabel_2 = Instance.new("TextLabel")
local TextButton_2 = Instance.new("TextButton")

--Properties:

ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame.Position = UDim2.new(0.417515248, 0, 0.219999999, 0)
Frame.Size = UDim2.new(0, 161, 0, 252)
Frame.Visible = false
Frame.Style = Enum.FrameStyle.DropShadow
Frame.Active = true
Frame.Draggable = true

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.Position = UDim2.new(0.0293857716, 0, 0.00630702451, 0)
TextLabel.Size = UDim2.new(0, 138, 0, 21)
TextLabel.Font = Enum.Font.Jura
TextLabel.Text = "Da Hood Hub"
TextLabel.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.TextSize = 22.000

combatgui1.Name = "combat gui - 1"
combatgui1.Parent = Frame
combatgui1.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
combatgui1.Position = UDim2.new(0.0255777836, 0, 0.137944058, 0)
combatgui1.Size = UDim2.new(0, 140, 0, 25)
combatgui1.Style = Enum.ButtonStyle.RobloxButton
combatgui1.Font = Enum.Font.SourceSansItalic
combatgui1.Text = "combat gui - 1"
combatgui1.TextColor3 = Color3.fromRGB(255, 255, 255)
combatgui1.TextSize = 18.000
combatgui1.MouseButton1Down:connect(function()
	loadstring(game:GetObjects("rbxassetid://5812737894")[1].Source)()
end)

combatgui2.Name = "combat gui - 2"
combatgui2.Parent = combatgui1
combatgui2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
combatgui2.Position = UDim2.new(-0.0744222179, 0, 2.89794397, 0)
combatgui2.Size = UDim2.new(0, 140, 0, 25)
combatgui2.Style = Enum.ButtonStyle.RobloxButton
combatgui2.Font = Enum.Font.SourceSansItalic
combatgui2.Text = "combat gui - 2"
combatgui2.TextColor3 = Color3.fromRGB(255, 255, 255)
combatgui2.TextSize = 18.000
combatgui2.MouseButton1Down:connect(function()
	--// Clone Detection
	for i, v in pairs(game:GetService("CoreGui"):GetChildren()) do
		if v.Name == "ScreenGui" then
			v:Destroy()
		end
	end

	repeat
		wait()
	until game:GetService("Players").LocalPlayer ~= nil

	if not game:GetService("Players").LocalPlayer.Character then
		game:GetService("Players").LocalPlayer.CharacterAdded:Wait()
	end



	--/ Variables & Da Hood Gui Clones Deletion

	local LocalPlayer = game:GetService("Players").LocalPlayer
	local Character = LocalPlayer.Character
	local Workspace = game:GetService("Workspace")
	local CoreGui = game:GetService("CoreGui")

	local LockedPlayer = nil
	local Aimlock = nil

	for i, v in pairs(game:GetService("CoreGui"):GetChildren()) do
		if v.Name == "dhgui" then
			v:Destroy()
		end
	end

	local mt = getrawmetatable(game)
	local namecall = mt.__namecall
	setreadonly(mt, false)

	if getrawmetatable then
		local mt = getrawmetatable(game)
		local namecall = mt.__namecall
		setreadonly(mt, false)

		mt.__namecall = newcclosure(function(table, ...)
			local args = {...}
			local method = getnamecallmethod()
			if method == "FireServer" and args[1] and args[1] == "UpdateMousePos" then
				if not (args[3] and args[3] == "Aimlock") then
					return nil
				end
			end
			return namecall(table, ...)
		end) 
	end

	local function FindPlrOnMouse()
		for i, v in pairs(game.Workspace:FindPartsInRegion3(Region3.new(LocalPlayer:GetMouse().Hit.Position, LocalPlayer:GetMouse().Hit.Position))) do
			local plr = game.Players:GetPlayerFromCharacter(v.Parent)
			if plr ~= nil and plr ~= LocalPlayer then
				return plr
			end
		end
		return nil
	end

	-- // Gui
	local ScreenGui = Instance.new("ScreenGui")
	local Frame = Instance.new("Frame")
	local TextButton = Instance.new("TextButton")
	local TextButton_2 = Instance.new("TextButton")
	local TextBox = Instance.new("TextBox")


	--// Gui Making

	ScreenGui.Parent = game.CoreGui
	ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

	Frame.Parent = ScreenGui
	Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Frame.Position = UDim2.new(0.30297032, 0, 0.475625843, 0)
	Frame.Size = UDim2.new(0, 397, 0, 211)
	Frame.Active = true
	Frame.Draggable = true



	TextButton.Parent = Frame
	TextButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextButton.Position = UDim2.new(0.0554156154, 0, 0.60189575, 0)
	TextButton.Size = UDim2.new(0, 136, 0, 50)
	TextButton.Font = Enum.Font.Cartoon
	TextButton.Text = "Aimlock Tool"
	TextButton.TextColor3 = Color3.fromRGB(0, 0, 0)
	TextButton.TextSize = 14.000


	TextButton_2.Parent = Frame
	TextButton_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextButton_2.Position = UDim2.new(0.570553482, 0, 0.60189575, 0)
	TextButton_2.Size = UDim2.new(0, 136, 0, 50)
	TextButton_2.Font = Enum.Font.Cartoon
	TextButton_2.Text = ""
	TextButton_2.TextColor3 = Color3.fromRGB(0, 0, 0)
	TextButton_2.TextSize = 14.000



	TextBox.Parent = Frame
	TextBox.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextBox.Position = UDim2.new(0.246851385, 0, 0.218009472, 0)
	TextBox.Size = UDim2.new(0, 200, 0, 50)
	TextBox.Font = Enum.Font.Cartoon
	TextBox.PlaceholderColor3 = Color3.fromRGB(178, 178, 178)
	TextBox.Text = ""
	TextBox.TextColor3 = Color3.fromRGB(0, 0, 0)
	TextBox.TextSize = 14.000


	TextButton.MouseButton1Click:connect(function()
		Aimlock = nil

		for i, v in pairs(LocalPlayer.Backpack:GetChildren()) do
			if v.ClassName == "Tool" and v.Name == "Aimlock Tool" then
				v:Destroy() 
			end
		end
		for i, v in pairs(LocalPlayer.Character:GetChildren()) do
			if v.ClassName == "Tool" and v.Name == "Aimlock Tool" then
				v:Destroy() 
			elseif v.ClassName == "Tool" then
				v.Parent = LocalPlayer.Backpack
			end
		end

		local AimlockTool = Instance.new("Tool")
		AimlockTool.Name = "Aimlock Tool"
		AimlockTool.Parent = LocalPlayer.Backpack
		AimlockTool.RequiresHandle = false
		AimlockTool.TextureId = "rbxasset://1532350639"

		AimlockTool.Activated:Connect(function()
			local Plr = FindPlrOnMouse()

			if Plr ~= nil and Plr.Character and Plr.Character:FindFirstChild("Head") and Plr.Character:FindFirstChild("UpperTorso") then
				Aimlock = Plr 

				game:GetService("StarterGui"):SetCore("SendNotification",{
					Title = "AIMLOCK | Corpse";
					Text = "Aimlocking towards: " .. Plr.Name .. ", use any gun and shoot anywhere";
					Button1 = "Ok";
					Duration = 2.5;
				})
			else
				Aimlock = nil

				game:GetService("StarterGui"):SetCore("SendNotification",{
					Title = "AIMLOCK | Corpse";
					Text = "No player clicked on, aimlocking towards mouse as normal";
					Button1 = "Ok";
					Duration = 2.5;
				})
			end
		end)
	end)

	if getrawmetatable then
		game:GetService("RunService").Heartbeat:Connect(function()
			if Aimlock ~= nil and Aimlock.Character and Aimlock.Character:FindFirstChild("Head") then
				game.ReplicatedStorage.MainEvent:FireServer("UpdateMousePos", Aimlock.Character.Head.Position, "Aimlock")
			elseif Aimlock ~= nil and Aimlock.Character and Aimlock.Character:FindFirstChildOfClass("Part") then
				game.ReplicatedStorage.MainEvent:FireServer("UpdateMousePos", Aimlock.Character:FindFirstChildOfClass("Part").Position, "Aimlock")
			elseif Aimlock == nil then
				game.ReplicatedStorage.MainEvent:FireServer("UpdateMousePos", game:GetService("Players").LocalPlayer:GetMouse().Hit.Position, "Aimlock")
			end
		end)
	else
		for i = 1, 10 do
			game:GetService("RunService").Heartbeat:Connect(function()
				if Aimlock ~= nil and Aimlock.Character and Aimlock.Character:FindFirstChild("Head") then
					game.ReplicatedStorage.MainEvent:FireServer("UpdateMousePos", Aimlock.Character.Head.Position)
				elseif Aimlock ~= nil and Aimlock.Character and Aimlock.Character:FindFirstChildOfClass("Part") then
					game.ReplicatedStorage.MainEvent:FireServer("UpdateMousePos", Aimlock.Character:FindFirstChildOfClass("Part").Position)
				end
			end)
			game:GetService("RunService").RenderStepped:Connect(function()
				if Aimlock ~= nil and Aimlock.Character and Aimlock.Character:FindFirstChild("Head") then
					game.ReplicatedStorage.MainEvent:FireServer("UpdateMousePos", Aimlock.Character.Head.Position)
				elseif Aimlock ~= nil and Aimlock.Character and Aimlock.Character:FindFirstChildOfClass("Part") then
					game.ReplicatedStorage.MainEvent:FireServer("UpdateMousePos", Aimlock.Character:FindFirstChildOfClass("Part").Position)
				end
			end)
			game:GetService("RunService").Stepped:Connect(function()
				if Aimlock ~= nil and Aimlock.Character and Aimlock.Character:FindFirstChild("Head") then
					game.ReplicatedStorage.MainEvent:FireServer("UpdateMousePos", Aimlock.Character.Head.Position)
				elseif Aimlock ~= nil and Aimlock.Character and Aimlock.Character:FindFirstChildOfClass("Part") then
					game.ReplicatedStorage.MainEvent:FireServer("UpdateMousePos", Aimlock.Character:FindFirstChildOfClass("Part").Position)
				end
			end)
		end
	end

end)

combatgui3.Name = "combat gui - 3"
combatgui3.Parent = combatgui1
combatgui3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
combatgui3.Position = UDim2.new(-0.0744222179, 0, 6.25794411, 0)
combatgui3.Size = UDim2.new(0, 140, 0, 25)
combatgui3.Style = Enum.ButtonStyle.RobloxButton
combatgui3.Font = Enum.Font.SourceSansItalic
combatgui3.Text = "combat gui - 3"
combatgui3.TextColor3 = Color3.fromRGB(255, 255, 255)
combatgui3.TextSize = 18.000
combatgui3.MouseButton1Down:connect(function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/XPLOIT-CORPSE/Free/main/SilentAim.lua"))()
end)

autofarmgui1.Name = "auto farm gui - 1"
autofarmgui1.Parent = combatgui3
autofarmgui1.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
autofarmgui1.Position = UDim2.new(-0.0672793612, 0, 2.37794399, 0)
autofarmgui1.Size = UDim2.new(0, 140, 0, 25)
autofarmgui1.Style = Enum.ButtonStyle.RobloxButton
autofarmgui1.Font = Enum.Font.SourceSansItalic
autofarmgui1.Text = "auto farm gui - 1"
autofarmgui1.TextColor3 = Color3.fromRGB(255, 255, 255)
autofarmgui1.TextSize = 18.000
autofarmgui1.MouseButton1Down:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/XPYGwFaT", true))()
end)

autofarmgui2.Name = "auto farm gui - 2"
autofarmgui2.Parent = autofarmgui1
autofarmgui2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
autofarmgui2.Position = UDim2.new(-0.0744222179, 0, 2.77794409, 0)
autofarmgui2.Size = UDim2.new(0, 140, 0, 25)
autofarmgui2.Style = Enum.ButtonStyle.RobloxButton
autofarmgui2.Font = Enum.Font.SourceSansItalic
autofarmgui2.Text = "auto farm gui - 2"
autofarmgui2.TextColor3 = Color3.fromRGB(255, 255, 255)
autofarmgui2.TextSize = 18.000
autofarmgui2.MouseButton1Down:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/AqLV4Wii", true))()
end)

TextButton.Parent = autofarmgui2
TextButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton.Position = UDim2.new(-0.0672793612, 0, 2.617944, 0)
TextButton.Size = UDim2.new(0, 140, 0, 25)
TextButton.Style = Enum.ButtonStyle.RobloxButton
TextButton.Font = Enum.Font.SourceSansItalic
TextButton.Text = "coming soon"
TextButton.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton.TextSize = 18.000

TextLabel_2.Parent = Frame
TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_2.BackgroundTransparency = 1.000
TextLabel_2.Position = UDim2.new(0.0164429098, 0, 0.9002437, 0)
TextLabel_2.Size = UDim2.new(0, 143, 0, 23)
TextLabel_2.Font = Enum.Font.Michroma
TextLabel_2.Text = "Made by Kody & Zac"
TextLabel_2.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_2.TextSize = 13.000

TextButton_2.Parent = ScreenGui
TextButton_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton_2.Position = UDim2.new(0.950101852, 0, 0.48237884, 0)
TextButton_2.Size = UDim2.new(0, 49, 0, 16)
TextButton_2.Style = Enum.ButtonStyle.RobloxButtonDefault
TextButton_2.Font = Enum.Font.SourceSans
TextButton_2.Text = "open"
TextButton_2.TextColor3 = Color3.fromRGB(0, 255, 0)
TextButton_2.TextSize = 16.000

-- Scripts:

local function KGMREE_fake_script() -- TextButton_2.Script 
	local script = Instance.new('Script', TextButton_2)

	game:GetService("StarterGui").ResetPlayerGuiOnSpawn = false
end
coroutine.wrap(KGMREE_fake_script)()
local function WEUI_fake_script() -- TextButton_2.Script 
	local script = Instance.new('Script', TextButton_2)

	local frame = script.Parent.Parent.Frame
	
	script.Parent.MouseButton1Click:Connect(function()
		if frame.Visible == false then
			frame.Visible = true
		else 
			frame.Visible = false
		end
	end)
end
coroutine.wrap(WEUI_fake_script)()